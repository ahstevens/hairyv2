#include "Isotrack.h"
#include <iostream>

int main(int argc, char * argv[])
{
    Isotrack i;
    if(!i.Initialize("COM1"))
        return 1;
    while(true)
    {
        Isotrack::State s = i.GetState(1);
        std::cout << "position: " << s.position[0] << "," << s.position[1] << "," << s.position[2] << "\tquaternion: " << s.orientation[0] << "," << s.orientation[1] << "," << s.orientation[2] << "," << s.orientation[3] << std::endl;
        Sleep(100);
    }
}
